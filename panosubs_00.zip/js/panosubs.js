﻿var fcpXmlTrackHdStartP1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?> <!DOCTYPE xmeml> <xmeml version=\"1\"> <sequence id=\"Subs_TH_Test\"> <name>";
var fcpXmlTrackHdStartP2 = "</name> <duration>100000</duration> <rate> <ntsc>FALSE</ntsc> <timebase>25</timebase> </rate> <timecode> <rate> <ntsc>FALSE</ntsc> <timebase>25</timebase> </rate> <string>10:00:00:00</string> <frame>900000</frame> <source>source</source> <displayformat>NDF</displayformat> </timecode> <in>-1</in> <out>-1</out> <media> <video> <format> <samplecharacteristics> <width>1920</width> <height>1080</height> <anamorphic>FALSE</anamorphic> <pixelaspectratio>Square</pixelaspectratio> <fielddominance>upper</fielddominance> <rate> <ntsc>FALSE</ntsc> <timebase>25</timebase> </rate> <colordepth>24</colordepth> <codec> <name>Apple ProRes 422 (HQ)</name> <appspecificdata> <appname>Final Cut Pro</appname> <appmanufacturer>Apple Inc.</appmanufacturer> <appversion>7.0</appversion> <data> <qtcodec> <codecname>Apple ProRes 422 (HQ)</codecname> <codectypename>Apple ProRes 422 (HQ)</codectypename> <codectypecode>apch</codectypecode> <codecvendorcode>appl</codecvendorcode> <spatialquality>1023</spatialquality> <temporalquality>0</temporalquality> <keyframerate>0</keyframerate> <datarate>0</datarate> </qtcodec> </data> </appspecificdata> </codec> </samplecharacteristics> <appspecificdata> <appname>Final Cut Pro</appname> <appmanufacturer>Apple Inc.</appmanufacturer> <appversion>7.0</appversion> <data> <fcpimageprocessing> <useyuv>TRUE</useyuv> <usesuperwhite>FALSE</usesuperwhite> <rendermode>Float10BPP</rendermode> </fcpimageprocessing> </data> </appspecificdata> </format> <track>";
var fcpXmlTextHdP0 = "<generatoritem id=\"";
var fcpXmlTextHdP1 = "\"> <name>Text</name> <duration>3000</duration> <rate> <ntsc>FALSE</ntsc> <timebase>25</timebase> </rate> <in>1500</in> <out>1575</out> <start>";
var fcpXmlTextHdP2 = "</start> <end>";
var fcpXmlTextHdP3 = "</end> <enabled>TRUE</enabled> <anamorphic>FALSE</anamorphic> <alphatype>black</alphatype> <logginginfo> <scene/> <shottake/> <lognote/> <good>FALSE</good> </logginginfo> <labels> <label2/> </labels> <comments> <mastercomment1/> <mastercomment2/> <mastercomment3/> <mastercomment4/> </comments> <effect> <name>Text</name> <effectid>Text</effectid> <effectcategory>Text</effectcategory> <effecttype>generator</effecttype> <mediatype>video</mediatype> <parameter> <parameterid>str</parameterid> <name>Text</name> <value>";
var fcpXmlTextHdP4 = "</value> </parameter> <parameter> <parameterid>fontname</parameterid> <name>Font</name> <value>Helvetica</value> </parameter> <parameter> <parameterid>fontsize</parameterid> <name>Size</name> <valuemin>0</valuemin> <valuemax>1000</valuemax> <value>18</value> </parameter> <parameter> <parameterid>fontstyle</parameterid> <name>Style</name> <valuemin>1</valuemin> <valuemax>4</valuemax> <valuelist> <valueentry> <name>Plain</name> <value>1</value> </valueentry> <valueentry> <name>Bold</name> <value>2</value> </valueentry> <valueentry> <name>Italic</name> <value>3</value> </valueentry> <valueentry> <name>Bold/Italic</name> <value>4</value> </valueentry> </valuelist> <value>1</value> </parameter> <parameter> <parameterid>fontalign</parameterid> <name>Alignment</name> <valuemin>1</valuemin> <valuemax>3</valuemax> <valuelist> <valueentry> <name>Left</name> <value>1</value> </valueentry> <valueentry> <name>Center</name> <value>2</value> </valueentry> <valueentry> <name>Right</name> <value>3</value> </valueentry> </valuelist> <value>2</value> </parameter> <parameter> <parameterid>fontcolor</parameterid> <name>Font Color</name> <value> <alpha>255</alpha> <red>255</red> <green>255</green> <blue>255</blue> </value> </parameter> <parameter> <parameterid>origin</parameterid> <name>Origin</name> <value> <horiz>-0</horiz> <vert>0.273743</vert> </value> </parameter> <parameter> <parameterid>fonttrack</parameterid> <name>Tracking</name> <valuemin>-200</valuemin> <valuemax>200</valuemax> <value>1</value> </parameter> <parameter> <parameterid>leading</parameterid> <name>Leading</name> <valuemin>-100</valuemin> <valuemax>100</valuemax> <value>0</value> </parameter> <parameter> <parameterid>aspect</parameterid> <name>Aspect</name> <valuemin>0.1</valuemin> <valuemax>5</valuemax> <value>1</value> </parameter> <parameter> <parameterid>autokern</parameterid> <name>Auto Kerning</name> <value>TRUE</value> </parameter> <parameter> <parameterid>subpixel</parameterid> <name>Use Subpixel</name> <value>TRUE</value> </parameter> </effect> <sourcetrack> <mediatype>video</mediatype> </sourcetrack> </generatoritem>";
var fcpXmlTrackHdEnd = " <enabled>TRUE</enabled> <locked>FALSE</locked> </track> </video> <audio> <format> <samplecharacteristics> <depth>16</depth> <samplerate>48000</samplerate> </samplecharacteristics> </format> <outputs> <group> <index>1</index> <numchannels>2</numchannels> <downmix>0</downmix> <channel> <index>1</index> </channel> <channel> <index>2</index> </channel> </group> </outputs> <in>-1</in> <out>-1</out> <track> <enabled>TRUE</enabled> <locked>FALSE</locked> <outputchannelindex>1</outputchannelindex> </track> <track> <enabled>TRUE</enabled> <locked>FALSE</locked> <outputchannelindex>2</outputchannelindex> </track> <track> <enabled>TRUE</enabled> <locked>FALSE</locked> <outputchannelindex>1</outputchannelindex> </track> <track> <enabled>TRUE</enabled> <locked>FALSE</locked> <outputchannelindex>2</outputchannelindex> </track> </audio> </media> </sequence> </xmeml>";



		var inputRate = 23.976;
		var outputRate = 25;
		var inputHourBase = 01;
		var outputHourBase = 10;
		var tcsFound = 1;
		var tcDividers = [":",".",",",";"];
		function tcDivider(divider)
		{
			for(var n=0; n<=tcDividers.length; n++)
			{
				//alert(tcDividers[n]);
				if(divider===tcDividers[n])
				{
					return tcDividers[n];
				}
			}
		}
		var sequenceName = "Default_Name";
		var indexOffset = 0;	
		
		function reduceFontSize()
		{
			var input = document.getElementById("input_text");
			var inputContent = input.innerHTML.toString();
	
			var output = document.getElementById("output_text");
			var outputContent = output.innerHTML;
			output.setAttribute("style","background-color: green; font-family:Arial, Helvetica; font-size:8px; line-height: 18px; text-decoration:none; color:white;");
		}
		function increaseFontSize()
		{
			var input = document.getElementById("input_text");
			var inputContent = input.innerHTML.toString();
	
			var output = document.getElementById("output_text");
			var outputContent = output.innerHTML;
			output.setAttribute("style","background-color: green; font-family:Arial, Helvetica; font-size:18px; line-height: 28px; text-decoration:none; color:white;");
		}

		function updateSettings()
		{
		var fpsSelected = document.getElementById("input_fps_selector").selectedIndex;
		var fpsOptions = document.getElementById("input_fps_selector").options;
		inputRate = parseFloat(fpsOptions[fpsSelected].text);
		var hourBaseSelected = document.getElementById("input_base_selector").selectedIndex;
		var hourBaseOptions = document.getElementById("input_base_selector").options;
		inputHourBase = parseFloat(hourBaseOptions[hourBaseSelected].text);
		var indexOffsetSelected = document.getElementById("index_offset_selector").selectedIndex;
		var indexOffsetOptions = document.getElementById("index_offset_selector").options;
		indexOffset = parseFloat(indexOffsetOptions[indexOffsetSelected].text);
		}
		
		function outputFormated(inArray)
		{ 
		outputString = inArray.join("");
		return outputString;
		}
		
		function Tc(number, inFrame, inTc, subtitle) {
  		this.number = number;
		this.inFrame = inFrame;
		this.outFrame = parseFloat(inFrame) + 75;
  		this.inTc = inTc;
		this.outChar = 1;
		this.subtitle = subtitle;
		}
		
		var subtitles = [];
		var newOutput = [];
		
		

		
function convertSubs()
{
		
		updateSettings();
		//alert(inputHourBase);
		
		var input = document.getElementById("input_text");
		var inputContent = input.innerHTML.toString();
		
	
		var output = document.getElementById("output_text");
		var outputContent = output.innerHTML;
		
		var totalInputContent = [];
		tcsFound = 1;
		subtitles = [];
		newOutput = [];
		
		
		//output.innerHTML = inputContent;

			
		for(var i in inputContent)
		{
		
			//if(inputContent[i] === ":")
			//	{
			//	alert("found a colon!")
			//	}
			//else if(inputContent[i].match(/:/i)) 
			//{
			//	alert("found a colon!")
			//}
			if(inputContent[i].match(/\d+/g))
			{
				var numbersInContent = [];
					//if content is a number regEx
					//alert(i);
				posFirstNumber = parseFloat(i);
				posSecondNumber = posFirstNumber+1;
				posFirstColon = posFirstNumber+2;
				posThirdNumber = posFirstNumber+3;
				posForthNumber = posFirstNumber+4;
				posSecondColon = posFirstNumber+5;
				posFifthNumber = posFirstNumber+6;
				posSixthNumber = posFirstNumber+7;
				posThirdColon = posFirstNumber+8;
				posSeventhNumber = posFirstNumber+9;
				posEighthNumber = posFirstNumber+10;
				//alert(posSecondNumber)
			
				if(inputContent[posSecondNumber].match(/\d+/g) && (inputContent[posFirstColon] === tcDivider(inputContent[posFirstColon])) && inputContent[posThirdNumber].match(/\d+/g) && inputContent[posForthNumber].match(/\d+/g) && (inputContent[posSecondColon] === tcDivider(inputContent[posSecondColon])) && inputContent[posFifthNumber].match(/\d+/g) && inputContent[posSixthNumber].match(/\d+/g) && (inputContent[posThirdColon] === tcDivider(inputContent[posThirdColon])) && inputContent[posSeventhNumber].match(/\d+/g) && inputContent[posEighthNumber].match(/\d+/g))
				{
					//alert(posSecondNumber);
					//if(inputContent[posFirstColon].match(/:/i))
					//alert("found a colon!")
					numbersInContent.push(inputContent[i], inputContent[posSecondNumber], inputContent[posThirdNumber], inputContent[posForthNumber], inputContent[posFifthNumber], inputContent[posSixthNumber], inputContent[posSeventhNumber], inputContent[posEighthNumber])
				
				//alert(numbersInContent.join(""));
			
			function convertToFrames()
			{
				//TH seperate number pairs to calculate total number of frames at a given TC 
				// then (eventually return that frame count at 25 fps instead
				// Use inputRate to define if source TCs are 23.98 or 24 FPS
				// Use outputRate to set desired output FPS default is 25 FPS
				// Use inputHourBase to define the programme start time and the effective zero hour
				// default will be 01 as is the norm for 23 and 24 FPS films
				function frames()
				{
				return parseFloat(numbersInContent[6] + numbersInContent[7]);
				};
				function seconds() 
				{
				inputSeconds =  parseFloat(numbersInContent[4] + numbersInContent[5])  
				outputSeconds = inputSeconds * inputRate;
				return outputSeconds.toFixed(2)
				};
				function minutes() 
				{
				inputMinutes =  parseFloat(numbersInContent[2] + numbersInContent[3])  
				outputMinutes = (inputMinutes * 60) * inputRate;
				return outputMinutes.toFixed(2)
				};
				function hours() 
				{
				inputHours =  parseFloat(numbersInContent[0] + numbersInContent[1])  
				outputHours = (((inputRate * 60) * 60) * inputHours) - (((inputRate * 60) * 60) * inputHourBase);
				return outputHours.toFixed(2)
				};
				function framesTotal()
				{
					return (parseFloat(frames()) + parseFloat(seconds()) + parseFloat(minutes()) + parseFloat(hours())).toFixed(0);
				}
	
				return framesTotal();
			}
			
			
			function convertToTc() 
			{
				var noOfSecondsTotal = convertToFrames() / outputRate;
				var noOfSeconds = noOfSecondsTotal % 60;
				var noOfMinutes = noOfSecondsTotal / 60;
				var noOfHours = noOfSecondsTotal / 3600;
				
				var hourPair = numberPairHours(noOfHours);
				var minutePair = numberPair(noOfMinutes % 60);
				var secondPair = numberPair(noOfSeconds % 60);
				var framePair = numberPair(convertToFrames() % outputRate);
				
				function numberPair(number)
				{
				return (parseInt(number, 10) + 100).toString().substr(1)
				}
				
				function numberPairHours(number)
				{
				return (parseInt(number, 10) + (100 + outputHourBase)).toString().substr(1)
				}
				
				return hourPair+":"+minutePair+":"+secondPair+":"+framePair;
			}
			var sub = new Tc(parseFloat(tcsFound), convertToFrames(), convertToTc(), "The subtitle text, which is not yet coded to pass through");
			subtitles[tcsFound] = sub;
			subtitles[tcsFound].inChar = posEighthNumber+1;
			function defineSubs()
			{
				for (j=1; j<subtitles.length; j++)
				{
					if(tcsFound>1)
					{
					subtitles[(tcsFound)-1].outChar = ((subtitles[parseFloat(tcsFound)].inChar)-11)
					subtitles[(tcsFound)-1].subtitle = inputContent.slice(subtitles[parseFloat(tcsFound)-1].inChar, subtitles[parseFloat(tcsFound-1)].outChar);
					if(subtitles[parseFloat(tcsFound)].outChar === 1)
						// 1 is the default .outChar. so this is used to catch the last sub
						{
						subtitles[parseFloat(tcsFound)].subtitle = inputContent.slice(subtitles[parseFloat(tcsFound)].inChar, subtitles[subtitles.length]);
						}
					}
					else
					{
						subtitles[parseFloat(tcsFound)].subtitle = inputContent.slice(subtitles[parseFloat(tcsFound)].inChar, subtitles[subtitles.length]);
					}
					
				}
			}
			defineSubs();
			tcsFound = (tcsFound) + 1;
			numbersInContent = [];
			sub = {};
			}
			else
			{
				if(tcsFound===1)
				{
					newOutput.push(inputContent[i]);
				}
				else
				{
					null;
					//newOutput.push(inputContent[i]);
				}
			}
				
		}
		else
		{
			if(tcsFound===1)
			{
				newOutput.push(inputContent[i]);
			}
			else
			{
				null;
				//newOutput.push(inputContent[i]);
			}
		}
			
	}
		//alert("Input Frame rate selected is" +fpsOptions[fpsSelected].text);
	function updateTextStyle()
		{	
		//output.setAttribute("style","");
		output.setAttribute("style","background-color: green; font-family:Arial, Helvetica; font-size:18px; line-height: 28px; text-decoration:none; color:white;");
		}
		
		//alert(subtitles);
	function updateSubs()
	{
		//FIRST OUTPUT ANY PRE tc CHARACTERS
		output.innerHTML = outputFormated(newOutput);
		for (k=1; k<subtitles.length; k++) 
		{
			newOutput.push(subtitles[k].inTc+" "+subtitles[k].subtitle);
			output.innerHTML = outputFormated(newOutput);	
		}
	};
	updateSubs();
	updateTextStyle();
		
}

function trim(str)
		{
			return str.replace(/^\s\s*/, "").replace(/\s\s*$/, "");	
		}

function cleanSubs()
{
	//For cleaning up formatting - returns the text alone
		var cleanString = [];
		var dirtyIn = [];
		var dirtyOut = [];
		
		for (p=1; p<subtitles.length; p++)
		{		
				subtitles[p].subtitle = subtitles[p].subtitle.toString();
				subtitles[p].subtitle = trim(subtitles[p].subtitle);
				//subtitles[p].subtitle = subtitles[p].subtitle.replace(/p>/g,"p> &#13; ");
				//subtitles[p].subtitle = subtitles[p].subtitle.replace(/<br>/g," &#13; ");
				subtitles[p].subtitle = subtitles[p].subtitle.replace(/&nbsp;/g," ");
				//alert("after "+subtitles[p].subtitle)
				
				for(var i in subtitles[p].subtitle)
				{	
					if(subtitles[p].subtitle[i]==="<")
					{
						//alert("< match found and is "+ i);
						dirtyIn.push(i);
					}
					else if(subtitles[p].subtitle[i]===">")
					{
						//alert("> match found and is "+ i);
						dirtyOut.push(parseFloat(i)+1);
					}
					else
					{
						null;	
					}
				}
				if(dirtyIn.length>0)
				{
					cleanString.push(subtitles[p].subtitle.substring(0,dirtyIn[0]));
					for(m=0; m<dirtyIn.length; m++)
					{
						//alert( subtitles[p].subtitle.substring(dirtyIn[m],dirtyOut[m]) );
						//alert(subtitles[p].subtitle.substring(dirtyOut[m],dirtyIn[(parseFloat(m)+1)]))
						cleanString.push(subtitles[p].subtitle.substring(dirtyOut[m],dirtyIn[(parseFloat(m)+1)]));
					}
				}
				else
				{
					cleanString.push(subtitles[p].subtitle);	
				}
				subtitles[p].subtitle = outputFormated(cleanString);
				
				cleanString = [];
				dirtyIn = [];
				dirtyOut = [];
				
				for(var i in subtitles[p].subtitle)
				{	
					if(subtitles[p].subtitle[i]==="[")
					{
						//alert("< match found and is "+ i);
						dirtyIn.push(i);
					}
					else if(subtitles[p].subtitle[i]==="]")
					{
						//alert("> match found and is "+ i);
						dirtyOut.push(parseFloat(i)+1);
					}
					else
					{
						null;	
					}
				}
				if(dirtyIn.length>0)
				{
					cleanString.push(subtitles[p].subtitle.substring(0,dirtyIn[0]));
					for(m=0; m<dirtyIn.length; m++)
					{
						//alert( subtitles[p].subtitle.substring(dirtyIn[m],dirtyOut[m]) );
						//alert(subtitles[p].subtitle.substring(dirtyOut[m],dirtyIn[(parseFloat(m)+1)]))
						cleanString.push(subtitles[p].subtitle.substring(dirtyOut[m],dirtyIn[(parseFloat(m)+1)]));
					}
				}
				else
				{
					cleanString.push(subtitles[p].subtitle);	
				}
				subtitles[p].subtitle = outputFormated(cleanString);

				if(subtitles[p].subtitle.match(/\x0A/g) )
				{
					subtitles[p].subtitle = subtitles[p].subtitle.replace((/\x0A/g),"&#13;")
					//alert("x0A New line character found");
				//alert(subtitles[o].number+" "+subtitles[o].subtitle+" found some letters");
				}
			
				subtitles[p].subtitle = trim(subtitles[p].subtitle);
				
				function tidyTop()
				{
					var subStart = (subtitles[p].subtitle.indexOf("&#13;"))+5;
					//alert(subStart);
					var subEnd = subtitles[p].subtitle.length;
					subtitles[p].subtitle = subtitles[p].subtitle.substring(subStart,subEnd);	
					subtitles[p].subtitle = trim(subtitles[p].subtitle);
					if(subtitles[p].subtitle.indexOf("&#13;")===0)
					{
					//alert("tidying");
						tidyTop();
					}
					else
					{
					null;
					}
				}
					
				if(subtitles[p].subtitle.indexOf("&#13;")===0)
				{
					//alert("tidying");
					tidyTop();
				}
				else
				{
				null;
				}
				
				//alert("Last index of Line Break is "+subtitles[p].subtitle.lastIndexOf("&#13;"));
				//alert("Subtitle length - 5 is "+((subtitles[p].subtitle.length)-5));
				
				function tidyBottom()
				{
					var subStart = 0;
					//alert(subStart);
					var subEnd = ((subtitles[p].subtitle.length)-5);
					subtitles[p].subtitle = subtitles[p].subtitle.substring(subStart,subEnd);	
					subtitles[p].subtitle = trim(subtitles[p].subtitle);
					if(subtitles[p].subtitle.lastIndexOf("&#13;")===((subtitles[p].subtitle.length)-5))
					{
						//alert("tidying");
						tidyBottom();
					}
					else
					{
					null;
					}
				}
				
				if(subtitles[p].subtitle.lastIndexOf("&#13;")===((subtitles[p].subtitle.length)-5))
				{
					//alert("tidying");
					tidyBottom();
				}
				else
				{
				null;
				}
	
				function tidyTopSpace()
				{
					subtitles[p].subtitle = subtitles[p].subtitle.replace((/ &#13;/g),"&#13;")
					if(subtitles[p].subtitle.match(/ &#13;/g) )
					{
						tidyTopSpace();
					}
					else
					{
					null;
					}
				}
				
				if(subtitles[p].subtitle.match(/ &#13;/g) )
				{
					tidyTopSpace();
				}
				else
				{
				null;
				}
				
				function tidyBottomSpace()
				{
					subtitles[p].subtitle = subtitles[p].subtitle.replace((/&#13; /g),"&#13;")
					if(subtitles[p].subtitle.match(/&#13; /g) )
					{
						tidyBottomSpace();
					}
					else
					{
					null;
					}
				}
				
				if(subtitles[p].subtitle.match(/&#13; /g) )
				{
					tidyBottomSpace();
				}
				else
				{
				null;
				}
				
				//alert(subtitles[p].subtitle);
				
				subtitles[p].subtitle = trim(subtitles[p].subtitle);
				
				//alert("clean string = " +subtitles[p].subtitle);
				cleanString = [];
				dirtyIn = [];
				dirtyOut = [];
		}
}
function sortSubs()
{
	//For organising subs - if w/ IN's and out's - removing source doc sub index numbers
	if(tcsFound>2)
	{
		for (o=1; o<subtitles.length; o++)
		{
			subtitles[o].hasNoLetters = true;
			if(subtitles[o].subtitle.match(/\S/g) )
			{
				subtitles[o].hasNoLetters = false;
				//alert(subtitles[o].number+" "+subtitles[o].subtitle+" found some letters");
			}
			//alert(subtitles[o].number+" found no letters = "+subtitles[o].hasNoLetters);
		}
		for (o=1; o<subtitles.length; o++)
		{
			if(subtitles[o].hasNoLetters === true)
			{
				subtitles[(o)+1].outFrame = subtitles[(o)+1].inFrame;
				subtitles[(o)+1].inFrame = subtitles[o].inFrame;
				subtitles.splice(o,1);
			}
		}
		for (o=1; o<subtitles.length; o++)
		{
			//alert(indexOffset);
			//alert(subtitles[o].subtitle.substring(0,((subtitles[o].subtitle.length)-indexOffset)));
			subtitles[o].subtitle = subtitles[o].subtitle.substring(0,((subtitles[o].subtitle.length)-indexOffset))
		}
	}
	else
	{
		null;
	}
}

function cleanSubOverlap()
{
		for (o=1; o<subtitles.length-1; o++)
		{
			//console.log(subtitles[o].outFrame);				
			//console.log(subtitles[o+1].inFrame);
			if(subtitles[o].outFrame >= subtitles[o+1].inFrame)
			{
				subtitles[o].outFrame = subtitles[o+1].inFrame-1;
			}				
		}
}


	function subsToXml()
	{
		var newXmlOutput = [];
		newXmlOutput.push(fcpXmlTrackHdStartP1);
		newXmlOutput.push(sequenceName);
		newXmlOutput.push(fcpXmlTrackHdStartP2);
		for (l=1; l<subtitles.length; l++) 
		{
			newXmlOutput.push(fcpXmlTextHdP0);
			newXmlOutput.push("Text" + subtitles[l].number);
			newXmlOutput.push(fcpXmlTextHdP1);
			newXmlOutput.push(subtitles[l].inFrame);
			newXmlOutput.push(fcpXmlTextHdP2);
			newXmlOutput.push(subtitles[l].outFrame);
			newXmlOutput.push(fcpXmlTextHdP3);
			newXmlOutput.push(subtitles[l].subtitle);
			newXmlOutput.push(fcpXmlTextHdP4);
		}
		newXmlOutput.push(fcpXmlTrackHdEnd);
		
		return outputFormated(newXmlOutput);
	}; 
	
	//End of subsToXml function
	
	
	// "COULDBEBETTER SAVE TXT DEMO MODDED
	function saveTextAsFile()
	{
	convertSubs();
	cleanSubs();
	sortSubs();
cleanSubOverlap();
	sequenceName = document.getElementById("inputSequenceNameToSaveAs").value;
	//var output = document.getElementById("output_text");
	var outputContent = subsToXml();
	var textToWrite = outputContent.toString();
	var textFileAsBlob = new Blob([textToWrite], {type:'text/xml'});
	var fileNameToSaveAs = document.getElementById("inputFileNameToSaveAs").value+".xml";
	

	var downloadLink = document.createElement("a");
	downloadLink.download = fileNameToSaveAs;
	downloadLink.innerHTML = "Download File";
	if (window.webkitURL != null)
	{
		// Chrome allows the link to be clicked
		// without actually adding it to the DOM.
		downloadLink.href = window.webkitURL.createObjectURL(textFileAsBlob);
	}
	else
	{
		// Firefox requires the link to be added to the DOM
		// before it can be clicked.
		downloadLink.href = window.URL.createObjectURL(textFileAsBlob);
		downloadLink.onclick = destroyClickedElement;
		downloadLink.style.display = "none";
		document.body.appendChild(downloadLink);
	}

	downloadLink.click();
}

function destroyClickedElement(event)
{
	document.body.removeChild(event.target);
}

function loadFileAsText()
{
	var fileToLoad = document.getElementById("fileToLoad").files[0];

	var fileReader = new FileReader();
	fileReader.onload = function(fileLoadedEvent) 
	{
		var textFromFileLoaded = fileLoadedEvent.target.result;
		var input = document.getElementById("input_text");
		input.innerHTML = textFromFileLoaded;
	};
	fileReader.readAsText(fileToLoad, "UTF-8");
}
